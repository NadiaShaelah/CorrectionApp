import fs, { readFileSync } from 'node:fs'
import * as XLSX from 'xlsx';

/* load 'fs' for readFile and writeFile support */
XLSX.set_fs(fs);


let files = fs.readdirSync('./Tp4StudentsCopy');

const searchQrRegex = /^Q(?<questionId>[0-9]+):([ ])?(?<response>.+)$/;
const searchQrRegexForFirstname = /^Nom:([ ])?(?<firstname>.+)$/;
const searchQrRegexForLastname = /^Prenom:([ ])?(?<lastname>.+)$/;
const searchQrRegexUserID = /^Numero etudiant:([ ])?(?<userId>.+)$/;

let etudiants = [];


for(let usersfilesTp4 = 0; usersfilesTp4 < files.length; usersfilesTp4++) {

    let fileContent = readFileSync(`./Tp4StudentsCopy/${files[usersfilesTp4]}`, {encoding: 'utf8'});

    const lines = fileContent.split("\n");

    // console.log("File System", lines);

    let responses = [];

    let reponseEnCoursDeParsing = undefined;

    for(let currentLigne of lines){
        
        let searchResult = searchResponseStart(currentLigne);
        
        if(reponseEnCoursDeParsing != undefined && !!searchResult){
            
            responses.push(reponseEnCoursDeParsing);

            reponseEnCoursDeParsing = searchResult
        } 
        else if(reponseEnCoursDeParsing != undefined && searchResult == undefined){
            reponseEnCoursDeParsing.lignes.push(currentLigne);
        } 

        else if(reponseEnCoursDeParsing == undefined){
            reponseEnCoursDeParsing = searchResult
        }

    }
    responses.push(reponseEnCoursDeParsing);

    let note = 0;
    
    let userFistname = lines[0].match(searchQrRegexForFirstname)?.groups
    userFistname = {...userFistname}

    let userLastname = lines[1].match(searchQrRegexForLastname)?.groups
    userLastname = {...userLastname}

    let userID = lines[2].match(searchQrRegexUserID)?.groups
    userID = {...userID}

    let ipClasseB;
    let ipClasseC;

    if(userID.userId) {
        let userIDtoIp = userID.userId
        if(userIDtoIp.length === 3) {
            let threeToEight = userID.userId+"00000";
            let premierOctet = `${threeToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${threeToEight.substring(2, 4)}.`
            let troisiemeOctet = `${threeToEight.substring(4, 6)}.`
            let quatriemeOctet = `${threeToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        if(userIDtoIp.length === 4) {
            let fourToEight = userID.userId+"0000";
            let premierOctet = `${fourToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${fourToEight.substring(2, 4)}.`
            let troisiemeOctet = `${fourToEight.substring(4, 6)}.`
            let quatriemeOctet = `${fourToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        if(userIDtoIp.length === 5) {
            let fiveToEight = userID.userId+"000";
            let premierOctet = `${fiveToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${fiveToEight.substring(2, 4)}.`
            let troisiemeOctet = `${fiveToEight.substring(4, 6)}.`
            let quatriemeOctet = `${fiveToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        if(userIDtoIp.length === 6) {
            let sixToEight = userID.userId+"00";
            let premierOctet = `${sixToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${sixToEight.substring(2, 4)}.`
            let troisiemeOctet = `${sixToEight.substring(4, 6)}.`
            let quatriemeOctet = `${sixToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        if(userIDtoIp.length === 8) {
            let EightToEight = userID.userId;
            let premierOctet = `${EightToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${EightToEight.substring(2, 4)}.`
            let troisiemeOctet = `${EightToEight.substring(4, 6)}.`
            let quatriemeOctet = `${EightToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        
    }
    else {
        console.log("Cet etudiant n'a pas de numéro ID");
    }
    console.log("ipClasseC *** ", ipClasseC);
    console.log("ipClasseB *** ", ipClasseB);

    let currentEtudiantNotes = {
        Nom: userFistname.firstname,
        Prenom: userLastname.lastname,
        NumeroEtudiant: userID.userId
    };

    for(let i = 0; i < responses.length; i++) {
        let noteObtenue = 0;
        if(responses[i].questionId==1){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "non" ? 1 : 0
        }
        else if(responses[i].questionId==2){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "non" ? 1 : 0;
        }
        else if(responses[i].questionId==3){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "oui" ? 1 : 0;
        }
        else if(responses[i].questionId==4){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "non" ? 1 : 0;
        }
        else if(responses[i].questionId==5){
            noteObtenue = responses[i].lignes.join().substring(0,8) === ipClasseC.substring(0,8)  ? 0.5 : 0;
        }
        else if(responses[i].questionId==6){
            noteObtenue = responses[i].lignes.join() === "255.255.255.0 " ? 0.5 : 0;
        }
        else if(responses[i].questionId==7){
            noteObtenue = responses[i].lignes.join().substring(0,8) === ipClasseC.substring(0,8) ? 0.5 : 0;
        }
        else if(responses[i].questionId==8){
            noteObtenue = responses[i].lignes.join().substring(0,8) === ipClasseC.substring(0,8) ? 0.5 : 0;
        }
        else if(responses[i].questionId==9){
            noteObtenue = responses[i].lignes.join().toLowerCase().match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/) ? 0.5 : 0; //regex 0001.979B.6501 !!!
        }
        else if(responses[i].questionId==10){
            noteObtenue = responses[i].lignes.join().toLowerCase().match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/) ? 0.5 : 0; //regex 0001.979B.6501 !!!
        }
        else if(responses[i].questionId==11){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "oui" ? 0.5 : 0;
        }
        else if(responses[i].questionId==12){
            noteObtenue = responses[i].lignes.join().toLowerCase().includes("adresse ip") ? 0.5 : 0;
        }
        else if(responses[i].questionId==13){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "non" ? 0.5 : 0;
        }
        else if(responses[i].questionId==14){
            noteObtenue = responses[i].lignes.join().toLowerCase().includes("gateway") ? 1 : 0;
        }
        else if(responses[i].questionId==15){
            noteObtenue = Number(responses[i].lignes.join()) <= 128 ? 0.5 : 0;
        }
        else if(responses[i].questionId==16){
            noteObtenue = responses[i].lignes.join().substring(0,8) === ipClasseC.substring(0,8) ? 0.5 : 0;
        }
        else if(responses[i].questionId==17){
            noteObtenue = responses[i].lignes.join() === "255.255.255.0" ? 0.5 : 0;
        }
        else if(responses[i].questionId==18){
            noteObtenue = responses[i].lignes.join().substring(0,8) === ipClasseC.substring(0,8) ? 0.5 : 0;
        }
        else if(responses[i].questionId==19){
            noteObtenue = responses[i].lignes.join() === "255.255.255.0" ? 0.5 : 0;
        }
        else if(responses[i].questionId==20){
            noteObtenue = responses[i].lignes.join().substring(0,8) === ipClasseC.substring(0,8) ? 0.5 : 0;
        }
        else if(responses[i].questionId==21){
            noteObtenue = responses[i].lignes.join() === "255.255.255.0" ? 0.5 : 0;
        }
        else if(responses[i].questionId==22){
            noteObtenue = responses[i].lignes.join().substring(0,10) === ipClasseB.substring(0,10) ? 0.5 : 0;
        }
        else if(responses[i].questionId==23){
            noteObtenue = responses[i].lignes.join().substring(12,14) === "16" ? 0.5 : 0; //`${ipClasseB}/16`
        }
        else if(responses[i].questionId==24){
            noteObtenue = responses[i].lignes.join().substring(0,10) === ipClasseB.substring(0,10) ? 0.5 : 0;
        }
        else if(responses[i].questionId==25){
            noteObtenue = responses[i].lignes.join().substring(0,10) === ipClasseB.substring(0,10) ? 0.5 : 0;
        }
        else if(responses[i].questionId==26){
            noteObtenue = responses[i].lignes.join().substring(0,10) === ipClasseB.substring(0,10) ? 0.5 : 0;
        }
        else if(responses[i].questionId==27){
            noteObtenue = responses[i].lignes.join().substring(12,14) === "16" ? 0.5 : 0; //`${ipClasseB}/16`
        }
        else if(responses[i].questionId==28){
            noteObtenue = responses[i].lignes.join().substring(0,10) === ipClasseB.substring(0,10)  ? 0.5 : 0;
        }
        else if(responses[i].questionId==29){
            noteObtenue = responses[i].lignes.join().substring(0,10) === ipClasseB.substring(0,10)  ? 0.5 : 0;
        }
        else if(responses[i].questionId==30){// à liree  -- 10.12.01.12/16
            noteObtenue = responses[i].lignes.join().toLowerCase().substring(12,14) === "16" ? 1 : 0; //"r0: @reseau pc1 Masque intf, @reseau pc2 masque intf".toLowerCase() 
        }
        else if(responses[i].questionId==31){
            noteObtenue = responses[i].lignes.join().toLowerCase().substring(12,14) === "16" ? 1 : 0; //"r1: @reseau pc0 Masque intf, @reseau pc2 masque intf".toLowerCase() 
        }
        else if(responses[i].questionId==32){
            noteObtenue = responses[i].lignes.join().toLowerCase().substring(12,14) === "16" ? 1 : 0; //"r2: @reseau pc0 Masque intf, @reseau pc1 masque intf".toLowerCase() 
        }
        currentEtudiantNotes[`Q${responses[i].questionId}`] = noteObtenue;
        note += noteObtenue
    }
    if(note <= 10) {
        console.log(`${note}/20. Vous avez des réponses incorrectes, incomplètes et/ou vides.`);
    }
    else if(note > 10 && note <= 15) {
        console.log(`${note}/20. Bien, mais vous avez des réponses incorrectes, incomplètes et/ou vides.`);
    }
    else if(note > 15 && note <= 18) {
        console.log(`${note}/20. Très bien, mais vous avez des réponses incorrectes, incomplètes et/ou vides.`);
    }
    else if(note === 19) {
        console.log(`${note}/20. Très bien, mais vous avez surement une réponse incorrectes, incomplète et/ou vide.`);
    }
    else if(note === 20) {
        console.log(`${note}/20. Très bien !.`);
    }
    else {
        console.log(note);
    }
    currentEtudiantNotes.Notes = note
    etudiants.push(currentEtudiantNotes)
}
const wb = XLSX.utils.book_new()

const ws = XLSX.utils.json_to_sheet(
    etudiants,
    {
        header: ["Nom", "Prenom", "NumeroEtudiant", "Q1", "Q2", "Q3", "Q4", "Q5", "Q6", "Q7", "Q8", "Q9", "Q10", "Q11", "Q12", "Q13", "Q14", "Q15", "Q16", "Q17", "Q18", "Q19", "Q20", "Q21", "Q22", "Q23", "Q24", "Q25", "Q26", "Q27", "Q28", "Q29", "Q30", "Q31", "Q32", "Notes"],
        skipHeader: false
    }
)

XLSX.utils.book_append_sheet(wb, ws, "TP4")
XLSX.writeFile(wb, "ReportDeNotesTp4.xlsx")


function searchResponseStart(ligne){

    let result = ligne.match(searchQrRegex)?.groups

    if(result)
        return {questionId: result.questionId, lignes: [result.response]}
}