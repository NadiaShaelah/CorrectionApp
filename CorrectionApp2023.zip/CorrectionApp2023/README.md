RS-CORRECTION-APP est une application de correction de copies, des tps réseaux.
Le lancement du programme se fait à partir du nom du script qui vous interesse précedecé du mot clé "node",
vu qu'il a été crée dans un environnement nodeJs.
Exemple : node ScriptTp4.js
Automatiquement un fichier excel est crée, dans lequel vous pouvez voir les noms des étudiants et leurs notes, en fonction du script lancé.

NB : Vous pouvez lancer la commande "npm init -y " pour avoir accès à tous les modules installés pour la mise en place du projet.
