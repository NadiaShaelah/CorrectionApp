import fs, { readFileSync } from 'node:fs'
import * as XLSX from 'xlsx';

/* load 'fs' for readFile and writeFile support */
XLSX.set_fs(fs);

let files = fs.readdirSync('./Tp1StudentsCopy');

const searchQrRegex = /^Q(?<questionId>[0-9]+):([ ])?(?<response>.+)$/;
const searchQrRegexForFirstname = /^Nom:([ ])?(?<firstname>.+)$/;
const searchQrRegexForLastname = /^Prenom:([ ])?(?<lastname>.+)$/;
const searchQrRegexUserID = /^Numero etudiant:([ ])?(?<userId>.+)$/;


let etudiants = []; //Tableau des étudiants

for(let usersfiles = 0; usersfiles < files.length; usersfiles++) {

    let fileContent = readFileSync(`./Tp1StudentsCopy/${files[usersfiles]}`, {encoding: 'utf8'});

    const lines = fileContent.split("\n");
    // console.log("File System", lines);

    let responses = [];

    let reponseEnCoursDeParsing = undefined;

    for(let currentLigne of lines){
        
        let searchResult = searchResponseStart(currentLigne);
        
        if(reponseEnCoursDeParsing != undefined && !!searchResult){
            
            responses.push(reponseEnCoursDeParsing);

            reponseEnCoursDeParsing = searchResult
        } 
        else if(reponseEnCoursDeParsing != undefined && searchResult == undefined){
            reponseEnCoursDeParsing.lignes.push(currentLigne);
        } 

        else if(reponseEnCoursDeParsing == undefined){
            reponseEnCoursDeParsing = searchResult
        }

    }
    responses.push(reponseEnCoursDeParsing);

    let note = 0;
    
    let userFistname = lines[0].match(searchQrRegexForFirstname)?.groups
    userFistname = {...userFistname}

    let userLastname = lines[1].match(searchQrRegexForLastname)?.groups
    userLastname = {...userLastname}

    let userID = lines[2].match(searchQrRegexUserID)?.groups
    userID = {...userID}

    let ipClasseB;
    let ipClasseC;
    
    if(userID.userId) {
        let userIDtoIp = userID.userId
        if(userIDtoIp.length === 3) {
            let threeToEight = userID.userId+"00000";
            let premierOctet = `${threeToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${threeToEight.substring(2, 4)}.`
            let troisiemeOctet = `${threeToEight.substring(4, 6)}.`
            let quatriemeOctet = `${threeToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        if(userIDtoIp.length === 4) {
            let fourToEight = userID.userId+"0000";
            let premierOctet = `${fourToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${fourToEight.substring(2, 4)}.`
            let troisiemeOctet = `${fourToEight.substring(4, 6)}.`
            let quatriemeOctet = `${fourToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        if(userIDtoIp.length === 5) {
            let fiveToEight = userID.userId+"000";
            let premierOctet = `${fiveToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${fiveToEight.substring(2, 4)}.`
            let troisiemeOctet = `${fiveToEight.substring(4, 6)}.`
            let quatriemeOctet = `${fiveToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        if(userIDtoIp.length === 6) {
            let sixToEight = userID.userId+"00";
            let premierOctet = `${sixToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${sixToEight.substring(2, 4)}.`
            let troisiemeOctet = `${sixToEight.substring(4, 6)}.`
            let quatriemeOctet = `${sixToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        if(userIDtoIp.length === 8) {
            let EightToEight = userID.userId;
            let premierOctet = `${EightToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${EightToEight.substring(2, 4)}.`
            let troisiemeOctet = `${EightToEight.substring(4, 6)}.`
            let quatriemeOctet = `${EightToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        
    }
    else {
        console.log("Cet etudiant n'a pas de numéro ID");
    }

    let currentEtudiantNotes = {
        Nom: userFistname.firstname,
        Prenom: userLastname.lastname,
        NumeroEtudiant: userID.userId
    };

    /*Objet pour garder les traces des note de l'étudiant en train d'être noté, quand on créer la variable, on ajoute en même temps le nom de l'étudiant
    On commence à noter l'étudiant dans la boucle en bas, donc à la fin de chaque note attribué, on va garder la trace de la note avec l'objet currentEtudiantNote
    */
    
    for(let i = 0; i < responses.length; i++) {

        let noteObtenue = 0;

        if(responses[i].questionId==1){
            noteObtenue = responses[i].lignes.join().match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/) ? 1 : 0;
        }
        else if(responses[i].questionId==2){
            noteObtenue = responses[i].lignes.join().toLowerCase().replace(/\s/g, "") === "sw1" || responses[i].lignes.join().toLowerCase() === "switch1" ? 2 : 0;
        }
        else if(responses[i].questionId==3){
            noteObtenue = responses[i].lignes.join().toLowerCase().replace(/\s/g, "") === "oui" ? 1 : 0;
        }
        else if(responses[i].questionId==4){
            //Sur la même ligne séparé par des virgules !!!
            let Q4 = responses[i].lignes.join().toLowerCase().replace(/\s/g, "").split(',');
            if(Q4[0].substring(4).match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/) &&
            Q4[1].substring(4).match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/) &&
            Q4[2].substring(4).match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/) &&
            Q4[3].substring(4).match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/) &&
            Q4[4].substring(4).match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/)) {
                noteObtenue = 2;
            }
            0
        }
        else if(responses[i].questionId==5){
            noteObtenue = responses[i].lignes.join().toLowerCase().replace(/\s/g, "") === "oui"  ? 1 : 0;
        }
        else if(responses[i].questionId==6){
            //Sur la même ligne séparé par des virgules !!!
            let Q6 = responses[i].lignes.join().toLowerCase().replace(/\s/g, "").split(',');
            if(Q6[0].substring(4).match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/) &&
            Q6[1].substring(4).match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/) &&
            Q6[2].substring(4).match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/) &&
            Q6[3].substring(4).match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/) &&
            Q6[4].substring(4).match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/)) {
                noteObtenue = 2;
            }
            0
        }
        else if(responses[i].questionId==7){
            noteObtenue = responses[i].lignes.join().toLowerCase().replace(/\s/g, "") === "non" ? 1 : 0;
        }
        else if(responses[i].questionId==8){
            noteObtenue = responses[i].lignes.join().toLowerCase().replace(/\s/g, "") === "arp" || responses[i].lignes.join().toLowerCase().replace(/\s/g, "").includes("arp") ? 2 : 0;
        }
        else if(responses[i].questionId==9){
            noteObtenue = responses[i].lignes.join().replace(/\s/g, "").match(/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/) ? 2 : 0;
        }
        else if(responses[i].questionId==10){
            noteObtenue = responses[i].lignes.join().toLowerCase().replace(/\s/g, "") === "broadcast" || responses[i].lignes.join().toLowerCase().replace(/\s/g, "").includes("broadcast") ? 1 : 0;
        }
        else if(responses[i].questionId==11){
            noteObtenue = responses[i].lignes.join().toLowerCase().includes("rien") || responses[i].lignes.join().toLowerCase().includes("vide") ? 2 : 0;
        }
        else if(responses[i].questionId==12){
            let Q12 = responses[i].lignes.join().split(',')
            let TabQ12 = Q12[2]
            let TabQ12Item = TabQ12.trim().split(' ');
            noteObtenue = TabQ12Item[3].replace(/\s/g, "").match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/) ? 2 : 0;
        }
        else if(responses[i].questionId==13){
            let Q13 = responses[i].lignes.join().trim().split(' ');
            noteObtenue = Q13[2].replace(/\s/g, "").match(/^([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$/) ? 1 : 0;
        }

        currentEtudiantNotes[`Q${responses[i].questionId}`] = noteObtenue;
        note += noteObtenue

    }
    if(note < 10) {
        console.log(`${note}/20. Vous avez des réponses incorrectes, incomplètes et/ou vides.`);
    }
    else if(note >= 10 && note <= 15) {
        console.log(`${note}/20. Bien, mais vous avez des réponses incorrectes, incomplètes et/ou vides.`);
    }
    else if(note > 15 && note <= 18) {
        console.log(`${note}/20. Très bien, mais vous avez des réponses incorrectes, incomplètes et/ou vides.`);
    }
    else if(note === 19) {
        console.log(`${note}/20. Très bien, mais vous avez surement une réponse incorrectes, incomplète et/ou vide.`);
    }
    else if(note === 20) {
        console.log(`${note}/20. Très bien !.`);
    }
    else {
        console.log(note);
    }
    
    //On vient de finir le traitement d'un étudiant, donc on vas l'ajouter à la liste de tous les étudiants traité
    //Mais avant ça, on ajoute la note total
    currentEtudiantNotes.Notes = note;
    etudiants.push(currentEtudiantNotes)
}

const wb = XLSX.utils.book_new()

const ws = XLSX.utils.json_to_sheet(
    etudiants,
    {
        header: ["Nom", "Prenom", "NumeroEtudiant", "Q1", "Q2", "Q3", "Q4", "Q5", "Q6", "Q7", "Q8", "Q9", "Q10", "Q11", "Q12", "Q13", "Notes"],
        skipHeader: false
    }
)

XLSX.utils.book_append_sheet(wb, ws, "TP1")
XLSX.writeFile(wb, "ReportDeNotesTp1.xlsx")


function searchResponseStart(ligne){

    let result = ligne.match(searchQrRegex)?.groups

    if(result)
        return {questionId: result.questionId, lignes: [result.response]}
}