import fs, { readFileSync } from 'node:fs'
import * as XLSX from 'xlsx';

/* load 'fs' for readFile and writeFile support */
XLSX.set_fs(fs);

// 1)ajouter les étapes manquante dans le point de controle sur teams


let files = fs.readdirSync('./Tp3StudentsCopy');

const searchQrRegex = /^Q(?<questionId>[0-9]+):([ ])?(?<response>.+)$/;
const searchQrRegexForFirstname = /^Nom:([ ])?(?<firstname>.+)$/;
const searchQrRegexForLastname = /^Prenom:([ ])?(?<lastname>.+)$/;
const searchQrRegexUserID = /^Numero etudiant:([ ])?(?<userId>.+)$/;

let etudiants = [];

for(let usersfilesTp3 = 0; usersfilesTp3 < files.length; usersfilesTp3++) {

    let fileContent = readFileSync(`./Tp3StudentsCopy/${files[usersfilesTp3]}`, {encoding: 'utf8'});
    const lines = fileContent.split("\n");

    // console.log("File System", lines);

    let responses = [];

    let reponseEnCoursDeParsing = undefined;

    for(let currentLigne of lines){
        
        let searchResult = searchResponseStart(currentLigne);
        
        if(reponseEnCoursDeParsing != undefined && !!searchResult){
            
            responses.push(reponseEnCoursDeParsing);

            reponseEnCoursDeParsing = searchResult
        } 
        else if(reponseEnCoursDeParsing != undefined && searchResult == undefined){
            reponseEnCoursDeParsing.lignes.push(currentLigne);
        } 

        else if(reponseEnCoursDeParsing == undefined){
            reponseEnCoursDeParsing = searchResult
        }

    }
    responses.push(reponseEnCoursDeParsing);

    let note = 0;

    let userFistname = lines[0].match(searchQrRegexForFirstname)?.groups
    userFistname = {...userFistname}

    let userLastname = lines[1].match(searchQrRegexForLastname)?.groups
    userLastname = {...userLastname}

    let userID = lines[2].match(searchQrRegexUserID)?.groups
    userID = {...userID}

    let currentEtudiantNotes = {
        Nom: userFistname.firstname,
        Prenom: userLastname.lastname,
        NumeroEtudiant: userID.userId
    };
    
    for(let i = 0; i < responses.length; i++) {
        let noteObtenue = 0;
        if(responses[i].questionId==1){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "icmp" || responses[i].lignes.join().toLowerCase().replace(/\s/g, "").substring(0, 4) === "icmp" ? 1 : 0;
        }
        else if (responses[i].questionId == 2) {
            noteObtenue = responses[i].lignes.join().match(/^((25[0-5]|2[0-4][0-9]|[0-1]?[0-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|[0-1]?[0-9]?[0-9])$/) ? 1 : 0 //.match(/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/) ? 1 : 0;IP
        }
        else if(responses[i].questionId==3){
            noteObtenue = responses[i].lignes.join().match(/^((25[0-5]|2[0-4][0-9]|[0-1]?[0-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|[0-1]?[0-9]?[0-9])$/) ? 1 : 0 //=== "255.255.255.0" ? 1 : 0; 
        }
        else if(responses[i].questionId==4){
            noteObtenue = responses[i].lignes.join().match(/^((25[0-5]|2[0-4][0-9]|[0-1]?[0-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|[0-1]?[0-9]?[0-9])$/) ? 1 : 0 ? 1 : 0; //regex
        }
        else if (responses[i].questionId == 5) {
            noteObtenue = responses[i].lignes.join() !== " " ? 2 : 0; //Nombre de routeurs traversé
        }
        else if (responses[i].questionId == 6) { //Liste d'adresse traversé
            let Q6Tab = responses[i].lignes.join().replace(/\s/g, "").split(",");
            noteObtenue = Q6Tab[0].match(/^((25[0-5]|2[0-4][0-9]|[0-1]?[0-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|[0-1]?[0-9]?[0-9])$/) ? 2 : 0
        }
        else if(responses[i].questionId==7){ 
            noteObtenue = responses[i].lignes.join().toLowerCase().replace(/\s/g, "").includes("srp") && responses[i].lignes.join().toLowerCase().replace(/\s/g, "").includes("ether") && responses[i].lignes.join().toLowerCase().replace(/\s/g, "").includes("arp") && responses[i].lignes.join().toLowerCase().replace(/\s/g, "").includes("pdst") ? 1 : 0; //"srp(Ether()/ARP(pdst=@IP))".toLowerCase().replace(/\s/g, "")
        }
        else if(responses[i].questionId==8){//???
            noteObtenue = responses[i].lignes.join().match(/^((25[0-5]|2[0-4][0-9]|[0-1]?[0-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|[0-1]?[0-9]?[0-9])$/) ? 1 : 0; //???
        }
        else if(responses[i].questionId==9){
            noteObtenue = responses[i].lignes.join().toLowerCase().includes("bootp") && responses[i].lignes.join().toLowerCase().replace(/\s/g, "").includes("chaddr") && responses[i].lignes.join().toLowerCase().replace(/\s/g, "").includes("ciaddr='0.0.0.0'") && responses[i].lignes.join().toLowerCase().replace(/\s/g, "").includes("flags=1") ? 1 : 0;//"BOOTP(chaddr=@macsource,ciaddr='0.0.0.0',xid=10,flags=1)".toLowerCase()
        }
        else if(responses[i].questionId==10){
            noteObtenue = responses[i].lignes.join().toLowerCase() === 'options=[("message-type","discover"),"end"])'.toLowerCase() || responses[i].lignes.join().toLowerCase().includes('options=[("message-type","discover"),"end"])') ? 1 : 0; //GOOD
        }
        else if(responses[i].questionId==11){
            noteObtenue = responses[i].lignes.join().toLowerCase().includes("ciaddr") && responses[i].lignes.join().toLowerCase().replace(/\s/g, "").includes("chaddr") ? 2 : 0;
        }
        else if(responses[i].questionId==12){
            noteObtenue = responses[i].lignes.join().toLowerCase().includes("dhcp offer") ? 2 : 0;
        }
        else if(responses[i].questionId==13){
            noteObtenue = responses[i].lignes.join().toLowerCase().includes('options=[("message-type","request")'.toLowerCase()) ? 2 : 0;
        }
        else if(responses[i].questionId==14){
            noteObtenue = responses[i].lignes.join().toLowerCase().includes("Options=[message-type") || responses[i].lignes.join().toLowerCase().includes("subnet_mask") || responses[i].lignes.join().toLowerCase().includes("router") || responses[i].lignes.join().toLowerCase().includes("domain").toLowerCase() ? 2 : 0;
        }
        currentEtudiantNotes[`Q${responses[i].questionId}`] = noteObtenue;
        note += noteObtenue
    }
    
    if(note < 10) {
        console.log(`${note}/20. Vous avez des réponses incorrectes, incomplètes et/ou vides.`);
    }
    else if(note >= 10 && note <= 15) {
        console.log(`${note}/20. Bien, mais vous avez des réponses incorrectes, incomplètes et/ou vides.`);
    }
    else if(note > 15 && note <= 18) {
        console.log(`${note}/20. Très bien, mais vous avez des réponses incorrectes, incomplètes et/ou vides.`);
    }
    else if(note === 19) {
        console.log(`${note}/20. Très bien, mais vous avez surement une réponse incorrectes, incomplète et/ou vide.`);
    }
    else if(note === 20) {
        console.log(`${note}/20. Très bien !.`);
    }
    else {
        console.log(note);
    }
    currentEtudiantNotes.Notes = note
    etudiants.push(currentEtudiantNotes)
    
}

const wb = XLSX.utils.book_new()

const ws = XLSX.utils.json_to_sheet(
    etudiants,
    {
        header: ["Nom", "Prenom", "NumeroEtudiant", "Q1", "Q2", "Q3", "Q4", "Q5", "Q6", "Q7", "Q8", "Q9", "Q10", "Q11", "Q12", "Q13", "Q14", "Q15", "Q16", "Notes"],
        skipHeader: false
    }
)

XLSX.utils.book_append_sheet(wb, ws, "TP3")
XLSX.writeFile(wb, "ReportDeNotesTP3.xlsx")



function searchResponseStart(ligne){

    let result = ligne.match(searchQrRegex)?.groups

    if(result)
        return {questionId: result.questionId, lignes: [result.response]}
}