import fs, { readFileSync } from 'node:fs'
import * as XLSX from 'xlsx';

/* load 'fs' for readFile and writeFile support */
XLSX.set_fs(fs);


let files = fs.readdirSync('./Tp2StudentsCopy');

const searchQrRegex = /^Q(?<questionId>[0-9]+):([ ])?(?<response>.+)$/;
const searchQrRegexForFirstname = /^Nom:([ ])?(?<firstname>.+)$/;
const searchQrRegexForLastname = /^Prenom:([ ])?(?<lastname>.+)$/;
const searchQrRegexUserID = /^Numero etudiant:([ ])?(?<userId>.+)$/;

let etudiants = [];

for(let usersfilesTp2 = 0; usersfilesTp2 < files.length; usersfilesTp2++) {

    let fileContent = readFileSync(`./Tp2StudentsCopy/${files[usersfilesTp2]}`, {encoding: 'utf8'});

    const lines = fileContent.split("\n");

    // console.log("File System", lines);

    let responses = [];

    let reponseEnCoursDeParsing = undefined;

    for(let currentLigne of lines){
        
        let searchResult = searchResponseStart(currentLigne);
        
        if(reponseEnCoursDeParsing != undefined && !!searchResult){
            
            responses.push(reponseEnCoursDeParsing);

            reponseEnCoursDeParsing = searchResult
        } 
        else if(reponseEnCoursDeParsing != undefined && searchResult == undefined){
            reponseEnCoursDeParsing.lignes.push(currentLigne);
        } 

        else if(reponseEnCoursDeParsing == undefined){
            reponseEnCoursDeParsing = searchResult
        }

    }
    responses.push(reponseEnCoursDeParsing);

    let note = 0;

    let userFistname = lines[0].match(searchQrRegexForFirstname)?.groups
    userFistname = {...userFistname}

    let userLastname = lines[1].match(searchQrRegexForLastname)?.groups
    userLastname = {...userLastname}

    let userID = lines[2].match(searchQrRegexUserID)?.groups
    userID = {...userID}

    let ipClasseB;
    let ipClasseC;

    if(userID.userId) {
        let userIDtoIp = userID.userId
        if(userIDtoIp.length === 3) {
            let threeToEight = userID.userId+"00000";
            let premierOctet = `${threeToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${threeToEight.substring(2, 4)}.`
            let troisiemeOctet = `${threeToEight.substring(4, 6)}.`
            let quatriemeOctet = `${threeToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        if(userIDtoIp.length === 4) {
            let fourToEight = userID.userId+"0000";
            let premierOctet = `${fourToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${fourToEight.substring(2, 4)}.`
            let troisiemeOctet = `${fourToEight.substring(4, 6)}.`
            let quatriemeOctet = `${fourToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        if(userIDtoIp.length === 5) {
            let fiveToEight = userID.userId+"000";
            let premierOctet = `${fiveToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${fiveToEight.substring(2, 4)}.`
            let troisiemeOctet = `${fiveToEight.substring(4, 6)}.`
            let quatriemeOctet = `${fiveToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        if(userIDtoIp.length === 6) {
            let sixToEight = userID.userId+"00";
            let premierOctet = `${sixToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${sixToEight.substring(2, 4)}.`
            let troisiemeOctet = `${sixToEight.substring(4, 6)}.`
            let quatriemeOctet = `${sixToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        if(userIDtoIp.length === 8) {
            let EightToEight = userID.userId;
            let premierOctet = `${EightToEight.substring(0, 2)}.`
            let deuxiemeOctet = `${EightToEight.substring(2, 4)}.`
            let troisiemeOctet = `${EightToEight.substring(4, 6)}.`
            let quatriemeOctet = `${EightToEight.substring(6, 8)}`
            ipClasseB = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
            ipClasseC = `${premierOctet}${deuxiemeOctet}${troisiemeOctet}${quatriemeOctet}`
        }
        
    }
    else {
        console.log("Cet etudiant n'a pas de numéro ID");
    }
    console.log("ipClasseC *** ", ipClasseC);
    console.log("ipClasseB *** ", ipClasseB);
    let currentEtudiantNotes = {
        Nom: userFistname.firstname,
        Prenom: userLastname.lastname,
        NumeroEtudiant: userID.userId
    };

    for(let i = 0; i < responses.length; i++) {

        let noteObtenue = 0;

        if(responses[i].questionId==1){
            noteObtenue = responses[i].lignes.join().substring(0,8) === ipClasseC.substring(0,8) ? 1 : 0;
        }
        else if(responses[i].questionId==2){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "dhcp discover" || responses[i].lignes.join().toLowerCase().includes("dhcp discover") ? 2 : 0;
        }
        else if(responses[i].questionId==3){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "broadcast" || responses[i].lignes.join().toLowerCase().includes("broadcast") ? 1 : 0;
        }
        else if(responses[i].questionId==4){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "dhcp offer" || responses[i].lignes.join().toLowerCase().includes("dhcp offer") ? 2 : 0;
        }
        else if(responses[i].questionId==5){
            noteObtenue = responses[i].lignes.join().substring(0,8) === ipClasseC.substring(0,8) ? 2 : 0; //??
        }
        else if(responses[i].questionId==6){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "non" ? 1 : 0;
        }
        else if(responses[i].questionId==7){
            noteObtenue = responses[i].lignes.join().substring(0,8) === ipClasseC.substring(0,8) ? 1 : 0;
        }
        else if(responses[i].questionId==8){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "dns" || responses[i].lignes.join().toLowerCase().includes("dns") ? 2 : 0;
        }
        else if(responses[i].questionId==9){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "arp" || responses[i].lignes.join().toLowerCase().includes("arp") ? 1 : 0;
        }
        else if(responses[i].questionId==10){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "icmp" || responses[i].lignes.join().toLowerCase().includes("icmp")? 1 : 0;
        }
        else if(responses[i].questionId==11){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "oui" ? 1 : 0;
        }
        else if(responses[i].questionId==12){
            noteObtenue = responses[i].lignes.join().toLowerCase().includes("cdp et dtp") || responses[i].lignes.join().toLowerCase().includes("cdp dtp") ? 1 : 0;
        }
        else if(responses[i].questionId==13){
            noteObtenue = responses[i].lignes.join().toLowerCase().replace(/\s/g, "") === "30s" || responses[i].lignes.join().toLowerCase().replace(/\s/g, "") === "30secondes" ? 1 : 0;
        }
        else if(responses[i].questionId==14){
            noteObtenue = responses[i].lignes.join().toLowerCase().replace(/\s/g, "") === "0s" || responses[i].lignes.join().toLowerCase().replace(/\s/g, "") === "0seconde" || responses[i].lignes.join().toLowerCase().replace(/\s/g, "") === "0" ? 1 : 0;
        }
        else if(responses[i].questionId==15){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "non" || responses[i].lignes.join().toLowerCase().includes("non") ? 1 : 0;
        }
        else if(responses[i].questionId==16){
            noteObtenue = responses[i].lignes.join().toLowerCase() === "non" || responses[i].lignes.join().toLowerCase().includes("non") ? 1 : 0;
        }

        currentEtudiantNotes[`Q${responses[i].questionId}`] = noteObtenue;
        note += noteObtenue
    }
    
    if(note < 10) {
        console.log(`${note}/20. Vous avez des réponses incorrectes, incomplètes et/ou vides.`);
    }
    else if(note >= 10 && note <= 15) {
        console.log(`${note}/20. Bien, mais vous avez des réponses incorrectes, incomplètes et/ou vides.`);
    }
    else if(note > 15 && note <= 18) {
        console.log(`${note}/20. Très bien, mais vous avez des réponses incorrectes, incomplètes et/ou vides.`);
    }
    else if(note === 19) {
        console.log(`${note}/20. Très bien, mais vous avez surement une réponse incorrectes, incomplète et/ou vide.`);
    }
    else if(note === 20) {
        console.log(`${note}/20. Très bien !.`);
    }
    else {
        console.log("noteeeeeeeeeee :: ", note);
    }
    currentEtudiantNotes.Notes = note
    etudiants.push(currentEtudiantNotes)
}
const wb = XLSX.utils.book_new()

const ws = XLSX.utils.json_to_sheet(
    etudiants,
    {
        header: ["Nom", "Prenom", "NumeroEtudiant", "Q1", "Q2", "Q3", "Q4", "Q5", "Q6", "Q7", "Q8", "Q9", "Q10", "Q11", "Q12", "Q13", "Q14", "Q15", "Q16", "Notes"],
        skipHeader: false
    }
)

XLSX.utils.book_append_sheet(wb, ws, "TP2")
XLSX.writeFile(wb, "ReportDeNotesTp2.xlsx")



function searchResponseStart(ligne){

    let result = ligne.match(searchQrRegex)?.groups

    if(result)
        return {questionId: result.questionId, lignes: [result.response]}
}